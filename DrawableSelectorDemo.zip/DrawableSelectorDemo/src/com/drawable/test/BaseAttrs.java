package com.drawable.test;

import android.content.Context;

import com.example.drawableselectordemo.App;

public class BaseAttrs {
	public static final int INVAILD_VALUE = -1;
	
	protected Context mContext;
	
	protected BaseAttrs() {
		mContext = App.instance();
	}

}
