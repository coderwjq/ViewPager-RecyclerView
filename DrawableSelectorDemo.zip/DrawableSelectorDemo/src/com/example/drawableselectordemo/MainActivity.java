package com.example.drawableselectordemo;

import com.drawable.test.DrawableTools;
import com.drawable.test.ShapeAttrs;

import android.app.Activity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageView;

/**
 * 图片点击、普通等样式 采用代码实现  测试
 * @author apple
 * 2016-01-10 16:21:10
 */
public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initViews();
    }
    
    private void initViews() {
    	ImageView imageView = (ImageView) findViewById(R.id.imageView);
    	imageView.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				
			}
		});
    	DrawableTools.setImageDrawableWithStateList(imageView, 
    			new ShapeAttrs()    //画形状
    				.setNormalArgb("#D682A3")  //普通时的颜色
    				.setPressedArgb("#A8D499") //按下时的颜色
    				.setStrokeWidth(4)  //如果不希望有边框，不设置该属性即可，或设置为0
    				.shapeOval()     //形状为圆形， 还可以设置为矩形
    				.setStrokeNormalArgb("#0000ff")  //普通时边框的颜色
    				.setStrokePressedArgb("#F9DF92") //按下时边框的颜色
    			);
    	
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();
        if (id == R.id.action_settings) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}
